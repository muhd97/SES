# Zain's Settlements Enrichment Service

## Requirements

- **Java:** 17+
- **Internet connection:** Required for Maven dependencies.
- **IDE:** IntelliJ IDEA.

## Setup Instructions

### Step 1: Download and Extract

1. Download the project ZIP file.
2. Extract the contents of the ZIP file to a directory on your computer.

### Step 2: Open the Project in IntelliJ IDEA

1. Launch **IntelliJ IDEA**.
2. Click on **Open** and navigate to the folder where you extracted the project.
3. Select the project directory and click **OK**.

### Step 3: Wait for Indexing

IntelliJ IDEA will automatically index the project. This may take a few minutes. Wait until the indexing is complete.

## Build and Run

### Step 4: Build the Project

1. Open the Terminal inside IntelliJ IDEA (located at the bottom of the window).
2. Type the following command to build the project and press Enter:
   ```bash
   ./mvnw clean install
   ```

### Step 5: Run the Project

To run the project, you have two options:

#### Option 1: Run from IntelliJ IDEA

1. Click the green **Run** button (the play icon) located at the top of the IntelliJ IDEA window.

#### Option 2: Run from the Command Line

1. Open a terminal and navigate to the project directory.
2. Run the following command:
   ```bash
   ./mvnw spring-boot:run
   ```

## Accessing the Application

Once the application is running, you can access it in your web browser at:
[http://localhost:8080](http://localhost:8080)

## Accessing H2 Database Console

The in-memory database console can be accessed at:
[http://localhost:8080/h2-console](http://localhost:8080/h2-console)

**Use the following credentials to log in:**

- **JDBC URL:** `jdbc:h2:mem:sesdb`
- **User Name:** `user`
- **Password:** `password`

## Accessing Swagger UI

You can access Swagger UI and test the API endpoints at:
[http://localhost:8080/swagger-ui.html](http://localhost:8080/swagger-ui.html)

## API Endpoints

### Create Market Settlement Message

- **URL:** `/api/settlement`
- **Method:** `POST`
- **Request Body:**
    ```json
    {
        "tradeId": "16846548",
        "ssiCode": "OCBC_DBS_1",
        "amount": 12894.65,
        "currency": "USD",
        "valueDate": "2002-02-02"
    }
    ```
- **Response Body:**
    ```json
    {
        "tradeId": "16846548",
        "messageId": 1,
        "amount": 12894.65,
        "valueDate": "2002-02-02",
        "currency": "USD",
        "payerParty": {
            "accountNumber": "438421",
            "bankCode": "OCBCSGSGXXX"
        },
        "receiverParty": {
            "accountNumber": "05461368",
            "bankCode": "DBSSGB2LXXX"
        },
        "supportingInformation": "/BNF/FFC-4697132"
    }
    ```

### Fetch Existing Market Settlement Message

- **URL:** `/api/settlement/{tradeId}` (Replace `{tradeId}` with a valid trade ID, such as `16846548`).
- **Method:** `GET`
- **Response Body:**
    ```json
    {
        "tradeId": "16846548",
        "messageId": 1,
        "amount": 12894.65,
        "valueDate": "2002-02-02",
        "currency": "USD",
        "payerParty": {
            "accountNumber": "438421",
            "bankCode": "OCBCSGSGXXX"
        },
        "receiverParty": {
            "accountNumber": "05461368",
            "bankCode": "DBSSGB2LXXX"
        },
        "supportingInformation": "/BNF/FFC-4697132"
    }
    ```

## Assumptions

- Only the SSI codes provided in the appendix are valid.
- The application uses an in-memory H2 database for storing market settlement messages.
- If a user requests a settlement with an invalid or non-existent trade ID, the system will return a 404 Resource Not
  Found error.
- For any required fields in `TradeRequest`, the system will throw a `MethodArgumentNotValidException` if they are null
  or blank.
- If a user attempts to create a settlement with a trade ID that already exists, the system will throw a conflict error.
  Trade IDs must be unique.
- If an unsupported currency is passed in the request, the system does not currently validate against a list of accepted
  currencies and assumes all input currencies are valid unless additional logic is implemented.
- The system requires the valueDate to be in the "yyyy-MM-dd" format. This format is validated to ensure consistent and
  correct date entries. Any deviation from this format will result in a validation error.
- The service assumes that all provided SSI codes are valid and present in the database.
- The system assumes that any unexpected exceptions (not handled by specific exception handlers) will return a generic
  internal server error. This could be improved by adding more specific exception handlers as needed.
- The in-memory H2 database is initialized with a predefined set of data. If this initialization fails or is incomplete,
  the application might not function as expected.
- The service assumes that any failure during a transaction (e.g., saving a settlement message) will roll back any
  changes made during that transaction to maintain data integrity.
- Message id has to be a unique value.

## Additional Information

- For detailed logging, check the console output during application runtime.
- Make sure to review the Swagger UI for all available endpoints and their details.
- Important: The database gets reset every time the application is run due to drop table if exists statements in the
  data.sql file. If you do not want the database to be reset, please delete this line before rerunning and rebuilding
  the application.