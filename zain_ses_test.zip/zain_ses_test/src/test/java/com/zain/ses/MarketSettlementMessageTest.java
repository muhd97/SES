package com.zain.ses;

import com.google.gson.Gson;
import com.zain.ses.dto.MarketSettlementMessageDTO;
import com.zain.ses.dto.TradeRequestDTO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.math.BigDecimal;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Tests for the Market Settlement Message API.
 * This class verifies the functionality of the settlement message endpoints.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
public class MarketSettlementMessageTest {

    final String invalidTradeId = "999";
    final String validSsiCode = "DBS_OCBC_1";

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private Gson gson;

    /**
     * Test case to verify the response for fetching a settlement message with an invalid trade ID.
     *
     * @throws Exception if an error occurs during the mock MVC execution
     */
    @Test
    public void testGetMsmByInvalidTradeId() throws Exception {
        mockMvc.perform(get("/api/settlement/{tradeId}", invalidTradeId))
                .andExpect(status().isNotFound());
    }

    /**
     * Test case to create a settlement message and verify it can be retrieved successfully.
     *
     * @throws Exception if an error occurs during the mock MVC execution
     */
    @Test
    public void testPostRequest() throws Exception {
        String tradeId = "7777";
        BigDecimal amount = BigDecimal.valueOf(100.00);
        String currency = "USD";
        String valueDate = "2024-07-11";

        TradeRequestDTO requestBody = new TradeRequestDTO(tradeId, amount, currency, valueDate, validSsiCode);
        String jsonRequestBody = gson.toJson(requestBody);

        mockMvc.perform(post("/api/settlement")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonRequestBody))
                .andExpect(status().isCreated());

        MvcResult result = mockMvc.perform(get("/api/settlement/{tradeId}", tradeId))
                .andExpect(status().isOk())
                .andReturn();

        String jsonResponse = result.getResponse().getContentAsString();
        MarketSettlementMessageDTO response = gson.fromJson(jsonResponse, MarketSettlementMessageDTO.class);

        assertEquals(tradeId, response.getTradeId());
    }

    /**
     * Test case to verify the response for creating a settlement message with an invalid SSI code.
     *
     * @throws Exception if an error occurs during the mock MVC execution
     */
    @Test
    public void testPostRequestWithInvalidSsiCode() throws Exception {
        String tradeId = "8888";
        BigDecimal amount = BigDecimal.valueOf(150.00);
        String currency = "EUR";
        String valueDate = "2024-07-12";

        TradeRequestDTO requestBody = new TradeRequestDTO(tradeId, amount, currency, valueDate, "INVALID_SSI");
        String jsonRequestBody = gson.toJson(requestBody);

        mockMvc.perform(post("/api/settlement")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonRequestBody))
                .andExpect(status().isNotFound());
    }

    /**
     * Test case to verify the response for creating a settlement message with null fields.
     *
     * @throws Exception if an error occurs during the mock MVC execution
     */
    @Test
    public void testPostRequestWithNullFields() throws Exception {
        TradeRequestDTO requestBody = new TradeRequestDTO(null, null, null, null, validSsiCode);
        String jsonRequestBody = gson.toJson(requestBody);

        mockMvc.perform(post("/api/settlement")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonRequestBody))
                .andExpect(status().isBadRequest());
    }
}
