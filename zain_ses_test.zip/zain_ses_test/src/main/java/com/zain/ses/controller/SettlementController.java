package com.zain.ses.controller;

import com.google.gson.Gson;
import com.zain.ses.dto.MarketSettlementMessageDTO;
import com.zain.ses.dto.TradeRequestDTO;
import com.zain.ses.exception.ResourceNotFoundException;
import com.zain.ses.model.MarketSettlementMessage;
import com.zain.ses.model.SSI;
import com.zain.ses.service.MarketSettlementMessageService;
import com.zain.ses.service.SSIService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

/**
 * REST controller for handling requests related to Market Settlement Messages.
 */
@RestController
@RequestMapping("/api/settlement")
public class SettlementController {

    private static final Logger logger = LoggerFactory.getLogger(SettlementController.class);

    @Autowired
    private MarketSettlementMessageService service;
    @Autowired
    private SSIService ssiService;
    @Autowired
    private Gson gson;

    /**
     * Fetches a Market Settlement Message by trade ID.
     *
     * @param tradeId the ID of the trade to fetch
     * @return ResponseEntity containing the Market Settlement Message in JSON format
     * @throws ResourceNotFoundException if the Market Settlement Message is not found
     */
    @GetMapping("/{tradeId}")
    public ResponseEntity<String> fetchSettlementMessageByTradeId(@PathVariable String tradeId) {
        logger.info("Fetching market settlement message with tradeId: {}", tradeId);

        // DB call to fetch by id
        Optional<MarketSettlementMessage> msmOptional = Optional.ofNullable(service.fetchSettlementMessageByTradeId(tradeId));
        if (msmOptional.isEmpty()) {
            logger.error("Market settlement message not found with tradeId: {}", tradeId);
            throw new ResourceNotFoundException("MSM not found with tradeId: " + tradeId);
        }

        // get the MSM obj
        MarketSettlementMessageDTO response = service.prepareMarketSettlementMessage(msmOptional.get());
        logger.info("Fetched market settlement message: {}", response);

        return ResponseEntity.status(HttpStatus.OK).body(gson.toJson(response));
    }

    /**
     * Creates a new Market Settlement Message.
     *
     * @param tradeRequestDTO the TradeRequestDTO containing the details of the trade
     * @return ResponseEntity containing the created Market Settlement Message in JSON format
     * @throws ResourceNotFoundException if the SSI code is not found
     */
    @PostMapping
    public ResponseEntity<String> createSettlementMessage(@Valid @RequestBody TradeRequestDTO tradeRequestDTO) {
        logger.info("Saving market settlement message for tradeId: {}", tradeRequestDTO.getTradeId());

        String ssiCode = tradeRequestDTO.getSsiCode();
        Optional<SSI> ssiOptional = ssiService.fetchById(ssiCode);

        if (ssiOptional.isEmpty()) {
            logger.error("SSICode not found: {}", ssiCode);
            throw new ResourceNotFoundException("SSICode not found: " + ssiCode);
        }

        //create msm object
        MarketSettlementMessage marketSettlementMessage = service.createSettlementMessage(tradeRequestDTO, ssiOptional.get());

        //persist to db
        service.save(marketSettlementMessage);
        MarketSettlementMessageDTO response = service.prepareMarketSettlementMessage(marketSettlementMessage);
        logger.info("Saved market settlement message: {}", response);

        return ResponseEntity.status(HttpStatus.CREATED).body(gson.toJson(response));
    }
}
