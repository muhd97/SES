package com.zain.ses.model;

import com.google.gson.Gson;
import com.google.gson.annotations.Expose;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Entity class representing a Standard Settlement Instruction (SSI).
 */
@Data
@NoArgsConstructor
@Entity
@Table(name = "SSI")
@Slf4j
public class SSI {

    @Id
    @Column(name = "ssi_code")
    @Expose
    @NotBlank(message = "SSI code cannot be blank")
    private String ssiCode;

    @Column(name = "payer_account_number", nullable = false)
    @Expose
    @NotBlank(message = "Payer account number cannot be blank")
    private String payerAccountNumber;

    @Column(name = "payer_bank", nullable = false)
    @Expose
    @NotBlank(message = "Payer bank cannot be blank")
    private String payerBank;

    @Column(name = "receiver_account_number", nullable = false)
    @Expose
    @NotBlank(message = "Receiver account number cannot be blank")
    private String receiverAccountNumber;

    @Column(name = "receiver_bank", nullable = false)
    @Expose
    @NotBlank(message = "Receiver bank cannot be blank")
    private String receiverBank;

    @Column(name = "supporting_information")
    @Expose
    private String supportingInformation;

    /**
     * Constructs a new SSI with the specified details.
     *
     * @param ssiCode             the SSI code
     * @param payerAccountNumber   the payer's account number
     * @param payerBank           the payer's bank
     * @param receiverAccountNumber the receiver's account number
     * @param receiverBank         the receiver's bank
     */
    public SSI(String ssiCode, String payerAccountNumber, String payerBank, String receiverAccountNumber,
               String receiverBank) {
        this.ssiCode = ssiCode;
        this.payerAccountNumber = payerAccountNumber;
        this.payerBank = payerBank;
        this.receiverAccountNumber = receiverAccountNumber;
        this.receiverBank = receiverBank;
        log.info("Created SSI: {}", this);
    }

    @Override
    public String toString() {
        return new Gson().toJson(this);
    }
}
