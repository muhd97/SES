package com.zain.ses.exception;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * Class representing error details for exception handling.
 */
@Data
@AllArgsConstructor
public class ErrorDetails {
    /**
     * The type of error.
     */
    private String error;

    /**
     * The detailed message about the error.
     */
    private String message;

    /**
     * Additional details about the error.
     */
    private String details;
}
