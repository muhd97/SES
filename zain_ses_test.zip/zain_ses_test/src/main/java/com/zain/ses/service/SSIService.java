package com.zain.ses.service;

import com.zain.ses.model.SSI;
import com.zain.ses.repository.SSIRepository;
import jakarta.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Service class for managing {@link SSI} entities.
 * Provides methods to fetch SSIs from the repository.
 */
@Service
@Transactional
public class SSIService {

    private static final Logger logger = LoggerFactory.getLogger(SSIService.class);

    @Autowired
    SSIRepository ssiRepository;

    /**
     * Fetches an SSI by its code.
     *
     * @param ssiCode the code of the SSI to fetch
     * @return an Optional containing the SSI if found, or empty if not found
     */
    public Optional<SSI> fetchById(String ssiCode) {
        logger.info("Fetching SSI by code: {}", ssiCode);
        return ssiRepository.findById(ssiCode);
    }

    /**
     * Fetches all SSIs from the repository.
     *
     * @return a list of all SSIs
     */
    public List<SSI> fetchAll() {
        List<SSI> ssis = new ArrayList<>();
        ssiRepository.findAll().forEach(ssis::add);
        logger.info("Fetched all SSIs: {}", ssis.size());
        return ssis;
    }
}
