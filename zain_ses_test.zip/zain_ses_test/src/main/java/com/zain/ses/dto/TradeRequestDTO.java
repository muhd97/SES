package com.zain.ses.dto;

import com.google.gson.Gson;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;

/**
 * Data Transfer Object for Trade Requests.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TradeRequestDTO {

    private static final Logger logger = LoggerFactory.getLogger(TradeRequestDTO.class);

    /**
     * Trade ID, must not be blank.
     */
    @NotBlank(message = "Trade Id cannot be blank")
    private String tradeId;

    /**
     * Trade amount, must be positive and not null.
     */
    @NotNull(message = "Amount cannot be null")
    @Positive(message = "Amount must be positive")
    private BigDecimal amount;

    /**
     * Currency, must not be blank.
     */
    @NotBlank(message = "Currency cannot be blank")
    private String currency;

    /**
     * Value Date in yyyy-MM-dd format, must not be blank.
     */
    @NotBlank(message = "Value Date cannot be blank")
    @Pattern(regexp = "\\d{4}-\\d{2}-\\d{2}", message = "Invalid date format. Use yyyy-MM-dd")
    private String valueDate;

    /**
     * SSI Code, must not be blank.
     */
    @NotBlank(message = "SSI code cannot be blank")
    private String ssiCode;

    /**
     * Converts the object to a JSON string representation.
     *
     * @return JSON string representation of the object
     */
    @Override
    public String toString() {
        String jsonString = new Gson().toJson(this);
        logger.info("TradeRequestDTO JSON: {}", jsonString);
        return jsonString;
    }
}
