package com.zain.ses.service;

import com.zain.ses.dto.MarketSettlementMessageDTO;
import com.zain.ses.dto.TradeRequestDTO;
import com.zain.ses.model.MarketSettlementMessage;
import com.zain.ses.model.SSI;
import com.zain.ses.repository.MarketSettlementRepository;
import jakarta.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Service class for managing {@link MarketSettlementMessage} entities.
 * Provides methods to create, fetch, and prepare market settlement messages.
 */
@Service
@Transactional
public class MarketSettlementMessageService {

    private static final Logger logger = LoggerFactory.getLogger(MarketSettlementMessageService.class);

    @Autowired
    MarketSettlementRepository repository;

    /**
     * Fetches a MarketSettlementMessage by its trade ID.
     *
     * @param tradeId the trade ID of the MarketSettlementMessage to fetch
     * @return the MarketSettlementMessage associated with the trade ID
     */
    public MarketSettlementMessage fetchSettlementMessageByTradeId(String tradeId) {
        logger.info("Fetching MarketSettlementMessage by tradeId: {}", tradeId);
        return repository.findByTradeId(tradeId);
    }

    /**
     * Saves a MarketSettlementMessage to the repository.
     *
     * @param marketSettlementMessage the MarketSettlementMessage to save
     */
    public void save(MarketSettlementMessage marketSettlementMessage) {
        logger.info("Saving MarketSettlementMessage with tradeId: {}", marketSettlementMessage.getTradeId());
        repository.save(marketSettlementMessage);
    }

    /**
     * Creates a MarketSettlementMessage from a TradeRequestDTO and an SSI.
     *
     * @param tradeRequestDTOBody the TradeRequestDTO containing trade details
     * @param ssi the SSI associated with the settlement
     * @return the created MarketSettlementMessage
     */
    public MarketSettlementMessage createSettlementMessage(TradeRequestDTO tradeRequestDTOBody, SSI ssi) {
        MarketSettlementMessage marketSettlementMessage = new MarketSettlementMessage();
        marketSettlementMessage.setTradeId(tradeRequestDTOBody.getTradeId());
        marketSettlementMessage.setCurrency(tradeRequestDTOBody.getCurrency());
        marketSettlementMessage.setAmount(tradeRequestDTOBody.getAmount());
        marketSettlementMessage.setValueDate(tradeRequestDTOBody.getValueDate());
        marketSettlementMessage.setSsicode(ssi);
        logger.info("Created MarketSettlementMessage for tradeId: {}", tradeRequestDTOBody.getTradeId());
        return marketSettlementMessage;
    }

    /**
     * Prepares a MarketSettlementMessageDTO from a MarketSettlementMessage.
     *
     * @param marketSettlementMessage the MarketSettlementMessage to convert
     * @return the prepared MarketSettlementMessageDTO
     */
    public MarketSettlementMessageDTO prepareMarketSettlementMessage(MarketSettlementMessage marketSettlementMessage) {
        SSI ssi = marketSettlementMessage.getSsicode();

        // Creating payer party
        MarketSettlementMessageDTO.PayerParty payerParty = new MarketSettlementMessageDTO.PayerParty(ssi.getPayerAccountNumber(), ssi.getPayerBank());
        // Creating receiver party
        MarketSettlementMessageDTO.ReceiverParty receiverParty = new MarketSettlementMessageDTO.ReceiverParty(ssi.getReceiverAccountNumber(), ssi.getReceiverBank());

        // Preparing response
        MarketSettlementMessageDTO response = new MarketSettlementMessageDTO();

        response.setMessageId(marketSettlementMessage.getMessageId());
        response.setTradeId(marketSettlementMessage.getTradeId());
        response.setAmount(marketSettlementMessage.getAmount());
        response.setValueDate(marketSettlementMessage.getValueDate());
        response.setCurrency(marketSettlementMessage.getCurrency());
        response.setSupportingInformation(ssi.getSupportingInformation());
        response.setPayerParty(payerParty);
        response.setReceiverParty(receiverParty);

        logger.info("Prepared MarketSettlementMessageDTO for tradeId: {}", marketSettlementMessage.getTradeId());
        return response;
    }
}
