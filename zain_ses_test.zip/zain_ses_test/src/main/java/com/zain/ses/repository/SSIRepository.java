package com.zain.ses.repository;

import com.zain.ses.model.SSI;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 * Repository interface for managing {@link SSI} entities.
 * Provides CRUD operations and data access methods for SSI.
 */
@Repository
public interface SSIRepository extends CrudRepository<SSI, String> {
}
