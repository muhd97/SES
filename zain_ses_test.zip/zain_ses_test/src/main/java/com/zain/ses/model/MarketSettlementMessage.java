package com.zain.ses.model;

import com.google.gson.Gson;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;

/**
 * Entity class representing a Market Settlement Message (MSM).
 */
@Data
@NoArgsConstructor
@Entity
@Table(name = "MSM")
@Slf4j
public class MarketSettlementMessage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "message_id")
    private long messageId;

    @Column(name = "trade_id", nullable = false, unique = true)
    @NotBlank(message = "Trade ID cannot be blank")
    private String tradeId;

    @ManyToOne
    @JoinColumn(name = "ssi_code", nullable = false)
    @NotNull(message = "SSI code cannot be null")
    private SSI ssicode;

    @Column(name = "amount", nullable = false)
    @NotNull(message = "Amount cannot be null")
    private BigDecimal amount;

    @Column(name = "currency", nullable = false)
    @NotBlank(message = "Currency cannot be blank")
    private String currency;

    @Column(name = "value_date", nullable = false)
    @NotBlank(message = "Value date cannot be blank")
    private String valueDate;

    @Override
    public String toString() {
        Gson gson = new Gson();
        return gson.toJson(this);
    }
}
