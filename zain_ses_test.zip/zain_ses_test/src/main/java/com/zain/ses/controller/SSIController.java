package com.zain.ses.controller;

import com.google.gson.Gson;
import com.zain.ses.model.SSI;
import com.zain.ses.service.SSIService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * REST controller for handling requests related to SSIs.
 */
@RestController
@RequestMapping("/api/ssi")
public class SSIController {

    private static final Logger logger = LoggerFactory.getLogger(SSIController.class);

    @Autowired
    private SSIService service;
    @Autowired
    private Gson gson;

    /**
     * Fetches all SSIs from the service.
     *
     * @return ResponseEntity containing the list of all SSIs in JSON format
     */
    @GetMapping
    public ResponseEntity<String> getAllSSIs() {
        logger.info("Fetching all SSIs.");

        List<SSI> ssis = service.fetchAll();
        String jsonResponse = gson.toJson(ssis);

        logger.info("Fetched {} SSIs.", ssis.size());
        return ResponseEntity.ok(jsonResponse);
    }
}
