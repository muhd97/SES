package com.zain.ses.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Custom exception for handling bad request errors.
 */
public class BadRequestException extends RuntimeException {
    private static final Logger logger = LoggerFactory.getLogger(BadRequestException.class);

    /**
     * Constructs a new BadRequestException with the specified detail message.
     *
     * @param message the detail message
     */
    public BadRequestException(String message) {
        super(message);
        logger.error("BadRequestException: {}", message);
    }
}
