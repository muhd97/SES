package com.zain.ses.exception;

import com.google.gson.Gson;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;

/**
 * Global exception handler for handling various types of exceptions in the application.
 */
@ControllerAdvice
public class CustomGlobalExceptionHandler {

    private static final Logger logger = LoggerFactory.getLogger(CustomGlobalExceptionHandler.class);

    @Autowired
    Gson gson;

    /**
     * Handles general exceptions and returns a 500 Internal Server Error response.
     *
     * @param ex      the exception
     * @param request the web request
     * @return the response entity with error details
     */
    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseEntity<String> handleGlobalExceptions(Exception ex, WebRequest request) {
        String responseErrorMsg = "An unexpected error occurred.";
        logException(ex, request);
        ErrorDetails errorDetails = new ErrorDetails(responseErrorMsg, ex.getMessage(), request.getDescription(false));
        return buildResponseEntity(errorDetails, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    /**
     * Handles ResourceNotFoundExceptions and returns a 404 Not Found response.
     *
     * @param ex      the exception
     * @param request the web request
     * @return the response entity with error details
     */
    @ExceptionHandler(ResourceNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ResponseEntity<String> handleResourceNotFoundExceptions(ResourceNotFoundException ex, WebRequest request) {
        logException(ex, request);
        ErrorDetails errorDetails = new ErrorDetails("Resource not found", ex.getMessage(), request.getDescription(false));
        return buildResponseEntity(errorDetails, HttpStatus.NOT_FOUND);
    }

    /**
     * Handles BadRequestExceptions and returns a 400 Bad Request response.
     *
     * @param ex      the exception
     * @param request the web request
     * @return the response entity with error details
     */
    @ExceptionHandler(BadRequestException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<String> handleBadRequestExceptions(BadRequestException ex, WebRequest request) {
        logException(ex, request);
        ErrorDetails errorDetails = new ErrorDetails("Bad request", ex.getMessage(), request.getDescription(false));
        return buildResponseEntity(errorDetails, HttpStatus.BAD_REQUEST);
    }

    /**
     * Handles DataIntegrityViolationExceptions and returns a 409 Conflict response.
     *
     * @param ex      the exception
     * @param request the web request
     * @return the response entity with error details
     */
    @ExceptionHandler(DataIntegrityViolationException.class)
    @ResponseStatus(HttpStatus.CONFLICT)
    public ResponseEntity<String> handleDataIntegrityViolation(DataIntegrityViolationException ex, WebRequest request) {
        logException(ex, request);
        ErrorDetails errorDetails = new ErrorDetails(
                "Data Integrity Violation Error: A conflict may have occurred with the data integrity, possibly due to a duplicate entry conflict or constraint violation.",
                ex.getMessage(),
                request.getDescription(false)
        );
        return buildResponseEntity(errorDetails, HttpStatus.CONFLICT);
    }

    /**
     * Handles MethodArgumentNotValidExceptions and returns a 400 Bad Request response.
     *
     * @param ex      the exception
     * @param request the web request
     * @return the response entity with error details
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<String> handleMethodArgumentNotValidExceptions(MethodArgumentNotValidException ex, WebRequest request) {
        logException(ex, request);
        ErrorDetails errorDetails = new ErrorDetails("Validation error", ex.getMessage(), request.getDescription(false));
        return buildResponseEntity(errorDetails, HttpStatus.BAD_REQUEST);
    }

    /**
     * Handles IllegalArgumentExceptions and returns a 400 Bad Request response.
     *
     * @param ex      the exception
     * @param request the web request
     * @return the response entity with error details
     */
    @ExceptionHandler(IllegalArgumentException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<String> handleIllegalArgumentException(IllegalArgumentException ex, WebRequest request) {
        logException(ex, request);
        ErrorDetails errorDetails = new ErrorDetails("Validation error, Invalid input", ex.getMessage(), request.getDescription(false));
        return buildResponseEntity(errorDetails, HttpStatus.BAD_REQUEST);
    }

    /**
     * Logs the exception details.
     *
     * @param ex      the exception
     * @param request the web request
     */
    private void logException(Exception ex, WebRequest request) {
        logger.error("Exception: {} - Request Description: {}", ex.getMessage(), request.getDescription(false));
    }

    /**
     * Builds the response entity with the given error details and HTTP status.
     *
     * @param errorDetails the error details
     * @param status       the HTTP status
     * @return the response entity with error details and status
     */
    private ResponseEntity<String> buildResponseEntity(ErrorDetails errorDetails, HttpStatus status) {
        String json = gson.toJson(errorDetails);
        return new ResponseEntity<>(json, status);
    }
}
