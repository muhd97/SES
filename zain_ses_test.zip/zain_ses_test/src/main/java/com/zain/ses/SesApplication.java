package com.zain.ses;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Main entry point for the SES (Settlement Enrichment Service) application.
 * This class bootstraps the Spring Boot application and starts the embedded server.
 */
@SpringBootApplication
public class SesApplication {

    private static final Logger logger = LoggerFactory.getLogger(SesApplication.class);

    /**
     * Main method to start the SES application.
     *
     * @param args command line arguments passed during application startup
     */
    public static void main(String[] args) {
        logger.info("Starting SES Application...");
        SpringApplication.run(SesApplication.class, args);
        logger.info("SES Application started successfully.");
    }
}
