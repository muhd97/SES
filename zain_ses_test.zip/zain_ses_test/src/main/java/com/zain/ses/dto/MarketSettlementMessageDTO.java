package com.zain.ses.dto;

import com.google.gson.Gson;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;

/**
 * Data Transfer Object for Market Settlement Messages.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MarketSettlementMessageDTO {

    private static final Logger logger = LoggerFactory.getLogger(MarketSettlementMessageDTO.class);

    /**
     * Message ID.
     */
    private long messageId;

    /**
     * Trade ID, must not be empty or null.
     */
    @NotEmpty(message = "Trade Id cannot be empty")
    @NotNull(message = "Trade Id cannot be null")
    private String tradeId;

    /**
     * Trade amount, must be positive and not null.
     */
    @Positive(message = "Amount must be positive")
    @NotNull(message = "Amount cannot be null")
    private BigDecimal amount;

    /**
     * Currency, must not be empty or null.
     */
    @NotEmpty(message = "Currency cannot be empty")
    @NotNull(message = "Currency cannot be null")
    private String currency;

    /**
     * Value Date, must not be empty or null.
     */
    @NotEmpty(message = "Value Date cannot be empty")
    @NotNull(message = "Value Date cannot be null")
    private String valueDate;

    /**
     * Supporting information.
     */
    private String supportingInformation;

    /**
     * Payer party details, must not be null.
     */
    @NotNull(message = "Payer party details cannot be null")
    private PayerParty payerParty;

    /**
     * Receiver party details, must not be null.
     */
    @NotNull(message = "Receiver party details cannot be null")
    private ReceiverParty receiverParty;

    /**
     * Converts the object to a JSON string representation.
     *
     * @return JSON string representation of the object
     */
    @Override
    public String toString() {
        String jsonString = new Gson().toJson(this);
        logger.info("MarketSettlementMessageDTO JSON: {}", jsonString);
        return jsonString;
    }

    /**
     * Abstract class for Party details.
     */
    @Data
    @AllArgsConstructor
    private static abstract class Party {
        /**
         * Account Number, must not be empty or null.
         */
        @NotEmpty(message = "Account Number cannot be empty")
        @NotNull(message = "Account Number cannot be null")
        private String accountNumber;

        /**
         * Bank Code, must not be empty or null.
         */
        @NotEmpty(message = "Bank Code cannot be empty")
        @NotNull(message = "Bank Code cannot be null")
        private String bankCode;
    }

    /**
     * Payer Party details.
     */
    public static class PayerParty extends Party {
        public PayerParty(String accountNumber, String bankCode) {
            super(accountNumber, bankCode);
        }
    }

    /**
     * Receiver Party details.
     */
    public static class ReceiverParty extends Party {
        public ReceiverParty(String accountNumber, String bankCode) {
            super(accountNumber, bankCode);
        }
    }
}
