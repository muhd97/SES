package com.zain.ses.repository;

import com.zain.ses.model.MarketSettlementMessage;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 * Repository interface for managing {@link MarketSettlementMessage} entities.
 * Provides CRUD operations and custom data access methods for Market Settlement Messages.
 */
@Repository
public interface MarketSettlementRepository extends CrudRepository<MarketSettlementMessage, Long> {

    /**
     * Finds a Market Settlement Message by its trade ID.
     *
     * @param tradeId the trade ID associated with the Market Settlement Message
     * @return the Market Settlement Message associated with the given trade ID, or null if not found
     */
    MarketSettlementMessage findByTradeId(String tradeId);
}
